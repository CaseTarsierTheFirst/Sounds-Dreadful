Steps:
1. Open the Quartus project file `VGA.qpf`.
2. Add your solution code to `vga_face.sv`.
3. Open Platform Designer in Quartus. When it prompts for an input file, select the `vga.qsys` file.
4. In Platform Designer, click *Generate HDL*.
5. Now compile in Quartus as per usual.
